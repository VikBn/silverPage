$(".banner__close").click(function() {
    $(".banner").hide();
});
